from pygame import *
init()

# define global variables
width = 1000
height = 700
screen = display.set_mode((width, height))
dx =1
dy = 0
# frog globals
froggerImage = image.load("frog.png")
froggerImage = transform.scale(froggerImage, (70,50))
frog = Rect(600,500, froggerImage.get_width(), froggerImage.get_height())
px = 545
py = 0

# background image 
backgroundImage= image.load("background.jpg")
backgroundImage = transform.scale(backgroundImage,(1000,700))


# car globals
carImage = image.load("car.png")
carImage = transform.scale(carImage, (100,50))

carList = []
class carRecord():
	carRect = None
	carSpeed = 0
	
car1 = carRecord()
car2 = carRecord()
car3 = carRecord()
# cars 
# TASK 3 - Add more cars!
car1.carRect = Rect(400,500,carImage.get_width(), carImage.get_height())
car1.carSpeed = -4 
car2.carRect = Rect(400,600,carImage.get_width(), carImage.get_height())
car2.carSpeed = -4
car3.carRect = Rect(400,600,carImage.get_width(), carImage.get_height())
car3.carSpeed = -4

carList.append(car1)
carList.append(car2)
carList.append(car3)

gameOver = False

# TASK 1 draw the background function!
# define functions
def drawBackground():
	global screen, backgroundImage
	screen.blit(backgroundImage, (0,0))

	
# draw your background as you wish!

def drawPlayer():
	global screen, frog, froggerImage
	screen.blit(froggerImage, (px,645))

def moveFrog():
	global px, fro, py
	frog.move_ip(px,py)
	

# TASK 2 draw cars
carx = 500
cary = 595
def drawCars(x,y):
	global screen, carImage
	screen.blit(carImage, (x,y))
	
# TASK 4 - Move the cars. If they go off the screen then wrap them. 
def moveCars():
	pass
	
		
	

while not gameOver:
	carx += 4
	if carx > 940:
		carx = 0
	for e in event.get():
		# task 5 - Make frogger move up and down.
		if e.type == QUIT: 
			gameOver = True
		elif e.type == KEYDOWN:
			if e.key == K_LEFT:
				px += -4
			if e.key == K_RIGHT:
				px += 4
			if e.key == K_UP:
				py += 4
		elif e.type == KEYUP:
			if e.key == K_LEFT or e.key == K_RIGHT:
				px += 0
			
	
	# TASK 6 - Make a more polished frogger game :)
				
	# movement
	moveFrog()
	moveCars()
	# game mechanics
	##for cars in carList:
		##if cars.colliderect(player):
			# collided with car
			#exit()
	# drawing
	drawBackground()
	drawPlayer()
	drawCars(carx, cary)
	
	# show the newly drawn screen (double buffering)
	display.flip()
	# short delay to slow down animation.
	time.delay(5)
