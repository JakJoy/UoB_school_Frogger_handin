from pygame import *
from random import *
from math import*
init()
 
# define global variables
width = 1000
height = 700
screen = display.set_mode((width, height))
dx = 1
dy = 0
# frog globals
froggerImage = image.load("frog.png")
froggerImage = transform.scale(froggerImage, (70,50))
frog = Rect(600, 650, froggerImage.get_width(), froggerImage.get_height())
px = 0
py = 0
 
# background image 
backgroundImage = image.load("background.jpg")
backgroundImage = transform.scale(backgroundImage,(1000,700))
 
 
# car globals
carImage = image.load("car.png")
carImage = transform.scale(carImage, (100,50))

 
carList = []
class carRecord():
	carRect = None
	carSpeed = 0
 
car1 = carRecord()
car2 = carRecord()
car3 = carRecord()
# cars 
# TASK 3 - Add more cars!
car1.carRect = Rect(0,485,carImage.get_width(), carImage.get_height())
car1.carSpeed = 4 
car2.carRect = Rect(0,595,carImage.get_width(), carImage.get_height())
car2.carSpeed = 6
car3.carRect = Rect(0,380,carImage.get_width(), carImage.get_height())
car3.carSpeed = 5
 
carList.append(car1)
carList.append(car2)
carList.append(car3)
 
gameOver = False
 
# TASK 1 draw the background function!
# define functions
def drawBackground():
	global screen, backgroundImage
	screen.blit(backgroundImage, (0,0))
 
 
# draw your background as you wish!
 
def drawPlayer():
	global screen, frog, froggerImage
	screen.blit(froggerImage, frog)
 
def moveFrog():
	global px, py, frog
	frog.move_ip(px,py)
 
# TASK 2 draw cars
carx = 500
cary = 595
# def drawCars(x,y):
# 	global screen, carImage
# 	screen.blit(carImage, (x,y))
 
def drawCars():
	global screen, carImage, carList
	for c in carList:
		screen.blit(carImage, c.carRect)
		if c.carRect.x == 0:
			c.carSpeed = randint(4,6)
 
def collisions():
	global carx, cary, px, py
	distance = pow(((pow((carx)-px,2))+(pow((cary)-py,2))),0.5)
	if distance <27:
		return True
	else:
		return False 
		
# TASK 4 - Move the cars. If they go off the screen then wrap them. 
def moveCars():
	global width
	for c in carList:
		c.carRect.move_ip(c.carSpeed,0)
		if c.carRect.x >= width:
			c.carRect.x = 0
 
 
 
 
 
while not gameOver:
	for e in event.get():
		# task 5 - Make frogger move up and down.
		if e.type == QUIT: 
			gameOver = True
		elif e.type == KEYDOWN:
			if e.key == K_LEFT:
				px = -3
			if e.key == K_RIGHT:
				px = 3
			if e.key == K_UP:
				py = -3
			if e.key == K_DOWN:
				py = 3
		elif e.type == KEYUP:
			if e.key == K_LEFT or e.key == K_RIGHT:
				px = 0
			if e.key == K_UP or e.key == K_DOWN:
				py = 0
 
	# TASK 6 - Make a more polished frogger game :)
 
	# movement
	moveFrog()
	moveCars()
	# game mechanics
	#for cars in carList:
	#	if cars.colliderect(player):
	#		collided with car
	#		exit()
	collision = collisions()
	if collision == True:
		print("true")
	# drawing
	drawBackground()
	drawPlayer()
	drawCars()
 
	# show the newly drawn screen (double buffering)
	display.flip()
	# short delay to slow down animation.
	time.delay(5)
